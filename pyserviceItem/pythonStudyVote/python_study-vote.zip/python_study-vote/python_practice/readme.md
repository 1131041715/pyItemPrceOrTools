This is a small web practice project to learn about aiohttp.
